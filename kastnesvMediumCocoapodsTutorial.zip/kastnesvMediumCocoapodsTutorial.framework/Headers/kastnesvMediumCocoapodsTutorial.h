//
//  kastnesvMediumCocoapodsTutorial.h
//  kastnesvMediumCocoapodsTutorial
//
//  Created by Sven Kastner on 11.06.21.
//

#import <Foundation/Foundation.h>

//! Project version number for kastnesvMediumCocoapodsTutorial.
FOUNDATION_EXPORT double kastnesvMediumCocoapodsTutorialVersionNumber;

//! Project version string for kastnesvMediumCocoapodsTutorial.
FOUNDATION_EXPORT const unsigned char kastnesvMediumCocoapodsTutorialVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <kastnesvMediumCocoapodsTutorial/PublicHeader.h>


